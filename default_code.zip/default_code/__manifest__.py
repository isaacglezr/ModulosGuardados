# -*- coding: utf-8 -*-
{
    'name': "defaultCode_POS",

    'summary': """show default_code in POS""",

    'description': """
    when you install this module into your database, yo can see default_code
    inside point of sale module.
    """,

    'author': "Soluciones 4g",
    'website': "http://www.soluciones4g.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'POS',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'view/default_view.xml',
        #'templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
      # 'demo.xml',
    ],
    'installable'=True,
    'auto_install'=False,
}
