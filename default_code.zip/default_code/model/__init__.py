from . import defproduct
