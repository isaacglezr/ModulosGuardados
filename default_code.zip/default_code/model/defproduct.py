# -*- coding: utf-8 -*-

from odoo import models, fields

class Default(models.Model):

    _inherit = "product.template"

    default_code = fields.string()
